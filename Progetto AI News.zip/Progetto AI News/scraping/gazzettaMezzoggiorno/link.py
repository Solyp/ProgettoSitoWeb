import bs4, requests
import pandas as pd

def is_csv_empty(file_path):
    try:
        df = pd.read_csv(file_path)
        if df.empty:
            return True
        else:
            return False
    except pd.errors.EmptyDataError:
        return True

def isOld(elemento, listaDiliste):
    for x in listaDiliste:
        if elemento in x:
            return True
    return False

LINK = "https://www.lagazzettadelmezzogiorno.it/ricerca?q=intelligenza+artificiale&timerange=week&annoricerca=&page=1"
FILE_LINK = "gazzettaMezzoggiorno/links.csv"
FILE_NUOVILINK = "gazzettaMezzoggiorno/nuovi_link.csv"
response = requests.get(LINK)
response.raise_for_status()

zuppa = bs4.BeautifulSoup(response.text, 'html.parser')

div_notizie = zuppa.find("div", class_ = "cont_anteprima_ricerca_archivio")

p_notizie = div_notizie.find_all("p", class_ = "titolo")
listaLinks = []

for p in p_notizie:
    a_notizia = p.find("a")
    link_notizia = str(a_notizia.get("href"))
    if link_notizia not in listaLinks:
        listaLinks.append(link_notizia)

nuovi_link = []

if(is_csv_empty(FILE_LINK) == False):
    df = pd.read_csv(FILE_LINK)
    vecchi_link = df.values.tolist()
    for el in listaLinks:
        if isOld(el, vecchi_link) == False:
            nuovi_link.append(el)
    df = pd.DataFrame(nuovi_link)
    df.to_csv(FILE_LINK, index= False, mode="a", sep="\t", encoding='utf-8')    
    df.to_csv(FILE_NUOVILINK, index= False, sep="\t", encoding='utf-8')   
else:
    df = pd.DataFrame(listaLinks)
    df.to_csv(FILE_LINK, index= False, sep="\t", encoding='utf-8')